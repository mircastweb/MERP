﻿namespace Merp.Accountancy.QueryStack.Model
{
    public class OutgoingCreditNote : Invoice
    {
    }
}
