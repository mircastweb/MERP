﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Merp.Accountancy.QueryStack.Model
{
    public class IncomingCreditNote : Invoice
    {
    }
}
