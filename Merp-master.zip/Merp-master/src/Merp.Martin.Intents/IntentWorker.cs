﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Merp.Martin.Intents
{
    public class IntentWorker
    {


    }
}
