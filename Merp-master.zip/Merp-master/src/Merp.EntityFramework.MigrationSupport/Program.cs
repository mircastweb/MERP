﻿using System;

namespace Merp.EntityFramework.MigrationSupport
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
