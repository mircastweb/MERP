﻿namespace Merp.Accountancy.CommandStack.Services
{
    public interface IOutgoingCreditNoteNumberGenerator
    {
        string Generate();
    }
}
