﻿namespace Merp.Accountancy.Drafts.Model
{
    public class ProvidenceFund
    {
        public string Description { get; set; }

        public decimal? Rate { get; set; }

        public decimal? Amount { get; set; }
    }
}
