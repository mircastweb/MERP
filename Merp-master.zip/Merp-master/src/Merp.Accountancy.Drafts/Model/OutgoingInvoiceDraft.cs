﻿namespace Merp.Accountancy.Drafts.Model
{
    public class OutgoingInvoiceDraft : InvoiceDraft
    {
    }
}
