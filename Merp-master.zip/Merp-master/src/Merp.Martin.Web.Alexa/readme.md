﻿
./ngrok.exe http -bind-tls=true -host-header=rewrite 55279