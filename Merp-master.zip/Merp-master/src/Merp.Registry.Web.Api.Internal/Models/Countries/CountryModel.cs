﻿namespace Merp.Registry.Web.Api.Internal.Models.Countries
{
    public class CountryModel
    {
        public string Code { get; set; }

        public string DisplayName { get; set; }
    }
}
