﻿namespace Merp.Accountancy.Web.Models
{
    public enum IncomingDocumentTypes
    {
        IncomingInvoice,
        IncomingCreditNote
    }
}
