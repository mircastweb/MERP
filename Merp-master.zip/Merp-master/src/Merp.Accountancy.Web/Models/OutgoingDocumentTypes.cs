﻿namespace Merp.Accountancy.Web.Models
{
    public enum OutgoingDocumentTypes
    {
        OutgoingInvoice,
        OutgoingCreditNote
    }
}
