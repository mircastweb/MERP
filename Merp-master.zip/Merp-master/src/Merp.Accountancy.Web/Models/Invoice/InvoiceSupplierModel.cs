﻿using System;

namespace Merp.Accountancy.Web.Models.Invoice
{
    public class InvoiceSupplierModel
    {
        public Guid Id { get; set; }

        public string Name { get; set; }
    }
}
