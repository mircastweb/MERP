﻿using System;

namespace Merp.Accountancy.Web.Models.Invoice
{
    public class InvoiceCustomerModel
    {
        public Guid Id { get; set; }

        public string Name { get; set; }
    }
}
