﻿using System;

namespace Merp.Accountancy.Web.Models.Draft
{
    public class DraftCustomerModel
    {
        public Guid Id { get; set; }

        public string Name { get; set; }
    }
}
