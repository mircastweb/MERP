- how much are we grossing?
- how much did we gross in [YEAR]?
- what's the running gross income?
- how much are we netting?
- how much did we net in [YEAR]?
- what's our running net income?
- what's the running net income?

- has invoice [INVOICE NUMBER] been paid?
- was invoice [INVOICE NUMBER] paid?
